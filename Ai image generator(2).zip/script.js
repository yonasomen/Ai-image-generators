const submit = document.querySelector('#search-btn');
const apiKey = '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';
const inputText = document.querySelector('input');
const imageSec = document.querySelector('.image-section');


const getImage = async () =>{
  const options = {
    method: "POST",
    headers: {
     "Authorization": `Bearer ${apiKey}`,
     "Content-type": "Application/json"
    },
    body: JSON.stringify({
      prompt: inputText.value,
      size: "512x512",
      n: 1,
    })
  }
  try{
     const response = await fetch(`https://api.openai.com/v1/images/generations`, options)
     const data = await response.json();
     
     data?.data.forEach(imageObject =>{
       const imageContainer = document.createElement('div');
       imageContainer.classList.add('image-container');
       const imageElement = document.createElement('img');
       imageElement.setAttribute('src', imageObject.url)
      imageContainer.append(imageElement)
      imageSec.append(imageContainer)
     })
  }
  catch(error){
    console.error(Error);
  }
};

submit.addEventListener('click', getImage);